-- MySQL dump 10.13  Distrib 8.0.29, for Linux (x86_64)
--
-- Host: localhost    Database: developersba
-- ------------------------------------------------------
-- Server version	8.0.32-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dba_users_galleries`
--

DROP TABLE IF EXISTS `dba_users_galleries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dba_users_galleries` (
  `id_user_gallery` int NOT NULL AUTO_INCREMENT COMMENT 'hidden;true;true;Id;',
  `id_user` int NOT NULL DEFAULT '0' COMMENT 'select;true;true;Propietario; SELECT * FROM dba_users;',
  `name` varchar(255) DEFAULT NULL COMMENT 'varchar;true;true;Name;',
  `detail` text COMMENT 'richtext;false;true;Detail;',
  `file` varchar(255) DEFAULT NULL COMMENT 'file;true;true;File (1200);;80:650:1200:true',
  `field_order` int DEFAULT NULL COMMENT 'order;true;true;Order;',
  `date` datetime NOT NULL DEFAULT '2020-01-01 00:00:00' COMMENT 'hiddendatetime;false;true;Creation At;',
  `modified` datetime NOT NULL DEFAULT '2020-01-01 00:00:00' COMMENT 'hiddendatetime;false;true;Update At;',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'tinyint;true;false;Status;',
  PRIMARY KEY (`id_user_gallery`),
  KEY `ky_user` (`id_user`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3 COMMENT='true;true;false;son_of:users;Galerias';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dba_users_galleries`
--

LOCK TABLES `dba_users_galleries` WRITE;
/*!40000 ALTER TABLE `dba_users_galleries` DISABLE KEYS */;
INSERT INTO `dba_users_galleries` VALUES (1,1,'Foto 1','<p>sad sada da</p>','09032023_060417_18871652.jpg',1,'2023-03-09 06:03:55','2023-03-09 06:03:55',1),(2,1,'Segunda foto','ad ad asd as da',NULL,2,'2023-03-09 09:18:02','2023-03-09 09:18:02',-1),(3,1,'aasdasdasd','adsasdasd asd',NULL,3,'2023-03-09 09:19:01','2023-03-09 09:19:01',-1),(4,1,'aasdasdasd','adsasdasd asd',NULL,4,'2023-03-09 09:20:05','2023-03-09 09:20:05',-1),(5,1,'asd asd sadas d','d sdfgs dgsg sdg sd gf',NULL,5,'2023-03-09 09:20:34','2023-03-09 09:20:34',-1),(6,1,'aaaaaaaaaaa','bbbbbbbbbbbbb','09032023_101446_12631283.jpg',6,'2023-03-09 09:27:27','2023-03-09 10:14:46',1),(7,1,'gggg','<p>ggggggg</p>','09032023_110309_19887677.jpeg',7,'2023-03-09 11:03:09','2023-03-09 17:57:46',1),(8,3,'asdasd','asdsaddasdsad asd sad','10032023_152925_17566160.png',8,'2023-03-10 03:29:24','2023-03-10 03:29:24',1),(9,1,'adasd',NULL,'11032023_062656_13903272.png',9,'2023-03-11 06:26:55','2023-03-11 07:00:41',1);
/*!40000 ALTER TABLE `dba_users_galleries` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-01 17:37:17
