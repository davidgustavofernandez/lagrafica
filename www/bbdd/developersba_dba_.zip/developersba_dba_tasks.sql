-- MySQL dump 10.13  Distrib 8.0.29, for Linux (x86_64)
--
-- Host: localhost    Database: developersba
-- ------------------------------------------------------
-- Server version	8.0.32-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dba_tasks`
--

DROP TABLE IF EXISTS `dba_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dba_tasks` (
  `id_task` int NOT NULL AUTO_INCREMENT COMMENT 'hidden;true;true;Id;',
  `id_user_type_permission` int NOT NULL DEFAULT '0' COMMENT 'select;true;true;Sección; SELECT * FROM dba_users_types_permissions',
  `id_task_environment` int NOT NULL DEFAULT '0' COMMENT 'select;false;true;Ambiente; SELECT * FROM dba_tasks_environments',
  `name` varchar(255) DEFAULT NULL COMMENT 'varchar;true;true;Tarea;',
  `id_task_priority` int NOT NULL DEFAULT '0' COMMENT 'select;true;true;Prioridad; SELECT * FROM dba_tasks_priorities',
  `id_task_state` int NOT NULL DEFAULT '0' COMMENT 'select;true;true;Estado; SELECT * FROM dba_tasks_states',
  `detail` text COMMENT 'richtext;false;true;Detalle;',
  `comment` text COMMENT 'richtext;false;true;Comentario;',
  `file` varchar(255) DEFAULT NULL COMMENT 'file;false;true;Archivo;;0:0:0:true',
  `url` varchar(255) DEFAULT NULL COMMENT 'varcharlink;false;true;URL;',
  `id_task_people` int NOT NULL DEFAULT '0' COMMENT 'select;false;true;Propietario; SELECT * FROM dba_tasks_peoples',
  `id_task_resource` int NOT NULL COMMENT 'select;false;true;Recurso; SELECT * FROM dba_tasks_resources',
  `due_date` datetime DEFAULT '2019-04-07 00:00:00' COMMENT 'datetime;false;true;Fecha de entrega;',
  `id_task_sprint` int NOT NULL DEFAULT '0' COMMENT 'select;false;true;Sprint; SELECT * FROM dba_tasks_sprints',
  `field_order` int NOT NULL DEFAULT '0' COMMENT 'order;true;true;Orden;',
  `date` datetime NOT NULL DEFAULT '2019-04-07 00:00:00' COMMENT 'hiddendatetime;false;true;Creation At;',
  `modified` datetime NOT NULL DEFAULT '2019-04-07 00:00:00' COMMENT 'hiddendatetime;false;true;Update At;',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'tinyint;true;false;Status;',
  PRIMARY KEY (`id_task`),
  KEY `ky_task_peoples` (`id_task_people`),
  KEY `ky_task_resource` (`id_task_resource`),
  KEY `ky_task_state` (`id_task_state`),
  KEY `ky_task_sprint` (`id_task_sprint`),
  KEY `ky_task_environment` (`id_task_environment`),
  KEY `ky_task_priority` (`id_task_priority`),
  KEY `ky_user_type_permission` (`id_user_type_permission`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3 COMMENT='true;true;true;father:;Tareas';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dba_tasks`
--

LOCK TABLES `dba_tasks` WRITE;
/*!40000 ALTER TABLE `dba_tasks` DISABLE KEYS */;
INSERT INTO `dba_tasks` VALUES (1,23,1,'El campo localidad se puede escribir pero no queda grabado',1,7,'','<p>Se hicieron los ajustes necesarios.</p>',NULL,'',2,1,'2019-04-07 00:00:00',0,1,'2022-03-07 09:34:23','2022-03-17 05:24:04',1),(2,22,1,'Un paciente puede dejar de pertenecer temporalmente o definitivamente a una obra social',1,7,'<p>Debería haber un campo de baja de paciente, esta pantalla que permita hacer esos cambios.<br />\r\nSiempre mostrando los datos del paciente.<br />\r\nEn la pantalla de admisiones, evoluciones e historias clínicas.<br />\r\nDebería haber un mensaje al profesional que le avise que el paciente está dado de baja o no permitirle evolucionar.</p>','',NULL,'',2,1,'2019-04-07 00:00:00',0,2,'2022-03-07 09:34:23','2022-03-17 10:57:58',1),(3,15,1,'Control de 30 sesiones anuales en el caso de Psicología',1,7,'<p>Deberia figurar un mensaje en la historia clinica y la evolución cuando se excede dicha cantidad.<br />\r\nO cuando se pide el turno.</p>','<p>Ya esta aplicado en en momento de crear el turno.</p>',NULL,'',2,1,'2019-04-07 00:00:00',0,3,'2022-03-07 09:34:23','2022-05-15 21:57:51',1),(5,13,1,'Revisar la restricción de cantidad de caracteres al crear y editar',1,7,'<p>Ejemplo paciente: Arce Alvarez Tomas<br />\r\nDNI 50767680<br />\r\nProfesional: Cecilia Duarte.</p>','',NULL,'',2,1,'2019-04-07 00:00:00',0,5,'2022-03-07 09:34:23','2022-03-17 05:24:06',1),(4,8,1,'Error al crear, borrar y crear de nuevo una admisión',1,7,'<p>Si se carga una admision,&nbsp;luego se borra y se intenta cargar de nuevo, muestra un error de \"No se puede guardar el diagnostico ya existe un diagnostico para este paciente\".</p>','',NULL,'',2,1,'2019-04-07 00:00:00',0,4,'2022-03-07 09:34:23','2022-03-17 05:24:06',1),(6,15,1,'Hacer que figure la edad del paciente en el encabezado, al crear una evolución',1,7,'','',NULL,'',0,0,'2019-04-07 00:00:00',0,6,'2022-03-07 09:50:18','2022-03-17 05:24:07',1),(7,15,1,'Errores en las importaciones.',2,1,'<p>DE LOS 12 ARCHIVOS CONVERTIDOS AL NUEVO SISTEMA Y ENTREGADOS (DESDE EL 16-09 2020 AL 04-02-2022) FUERON PROCESADOS SOLO 9 (HASTA EL 14 DE ENERO 2022)<br />\r\n<br />\r\nSemanas del 17 al 21 de enero, 24 al 28 de enero y 31 de enero al 4 de febrero<br />\r\n<br />\r\nHAY EVOLUCIONES QUE HAN SIDO INCORPORADAS Y NO FIGURAN EN EL SISTEMA<br />\r\nDNI 22884031 lic ALCANTARA (22-12-2021)<br />\r\nDNI 47706135 MAMANI ANAEL DRA BETIANA DOMBROWSKI (5 DE ENERO 22)<br />\r\nDNI 46950477 AYALA FERRARI DRA BETIANA DOMBROWSKI (19 DE ENERO 22)<br />\r\nDNI 49122972 ROCCO MARISCAL DRA BETIANA DOMBROWSKI (5 DE ENERO 22)<br />\r\nDNI 48589819 DIAZ ESQUIVEL DRA BETIANA DOMBROWSKI(29 DE DICIEMBRE 21)</p>','',NULL,'',0,0,'2019-04-07 00:00:00',0,7,'2022-03-07 09:56:52','2022-03-07 09:57:03',1),(8,51,1,'Exportación de listado de historia clinica',2,1,'<p>LISTADO DE HISTORIA CLINICA PARA SER ENVIADO AL PACIENTE O A JUZGADOS</p>','',NULL,'',0,0,'2019-04-07 00:00:00',0,8,'2022-03-07 09:56:52','2022-03-07 09:59:39',1),(9,15,1,'Error en importación',2,1,'<p>ERRORES EN DATOS CONVERTIDOS ANTERIOR AL 15 DE SEPTIEMBRE 2020</p>','',NULL,'',0,0,'2019-04-07 00:00:00',0,9,'2022-03-07 09:56:52','2022-03-07 10:00:43',1),(10,8,1,'Que los usuarios ADMINISTRATIVOS puedan ver todos los registro listados y su detalle',2,7,'<p>hay usuarios(administrativos) que necesitan ver las ADMISIONES que realizan los profesionales<br />\r\nAclaro es solo ver NO MODIFICAR,, pues en base a ellas incorporan los pacientes a la lista de espera<br />\r\nPor supuesto en su perfil figura VER ADMISIONES<br />\r\nHasta ahora no había problema<br />\r\nPero hoy no se pueden ver&nbsp;<br />\r\nSe debe haber tocado algo del sistema,pues aparece el cartel SIN PERMISOS</p>','<p>Lo que hice fue agregar una excepción&nbsp;que consiste en que solo los usuarios con&nbsp;<strong>perfil ADMINISTRATIVO 2, (ID 14)&nbsp;</strong>van a poder aplicar estas acciones:<br />\r\n-<strong>&nbsp;Ver el listado</strong>&nbsp;completo de admisiones.<br />\r\n-&nbsp;<strong>Ver el detalle</strong>&nbsp;de una admisión.<br />\r\nLos permisos según perfiles y acciones para el resto sigue aplicándose como estaban.</p>',NULL,'',0,0,'2019-04-07 00:00:00',0,10,'2022-03-07 09:56:52','2022-03-17 15:52:34',1),(11,22,1,'Variable personalizada de sesiones por paciente',1,1,'<p>Agregar nueva variable en Pacientes para que se sume a la cantidad por mes (tiene que sumarse solo para el paciente)</p>',NULL,NULL,NULL,2,1,'2022-10-28 09:00:00',0,11,'2022-10-25 14:47:19','2022-10-25 14:47:19',1),(12,15,1,'Cantidad de turnos',1,1,'<p>Que muestre la cantidad de sesiones usadas por paciente valor anual.<br />\r\nEsto se muestra como indico leo en el header al momento de evolucionar</p>',NULL,NULL,NULL,2,1,'2022-10-28 09:00:00',0,12,'2022-10-25 14:49:11','2022-10-25 14:49:11',1),(13,29,1,'Ajuste en tabla de Seguimiento',1,1,'<p>Que la tabla actual se llame user_tracking_history<br />\r\nY crear&nbsp;user_tracking con el ID auto incremente ajustado al ultimo record insertado en el a de History</p>','',NULL,'',2,1,'2019-04-12 09:00:00',0,13,'2022-10-25 14:50:18','2022-10-25 14:52:40',1),(14,65,1,'Adjuntar archivos',2,1,'<p>Agregar la posibilidad en una historia clinica de poder adjuntar archivos como recetas comprobantes etc etc.<br />\r\nFalta definir formatos pesos etc etc.</p>','',NULL,'',2,1,'2019-04-12 09:00:00',0,14,'2022-10-25 14:50:18','2022-11-10 17:22:13',1),(15,78,1,'Agregar empresas al sistema (turnos)',1,2,'<p>Se necesita agregar la posibilidad de asignarle a los Profesionales la empresa a la que pertenecen para luego poder aplicar este filtro a toda la gestion de turnos.</p>','',NULL,'',2,1,'2019-04-12 09:00:00',6,15,'2022-10-25 14:50:18','2023-02-09 18:28:19',1);
/*!40000 ALTER TABLE `dba_tasks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-01 17:37:18
