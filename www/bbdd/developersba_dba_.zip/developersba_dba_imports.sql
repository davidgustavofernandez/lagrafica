-- MySQL dump 10.13  Distrib 8.0.29, for Linux (x86_64)
--
-- Host: localhost    Database: developersba
-- ------------------------------------------------------
-- Server version	8.0.32-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dba_imports`
--

DROP TABLE IF EXISTS `dba_imports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dba_imports` (
  `id_import` int NOT NULL AUTO_INCREMENT COMMENT 'hidden;true;true;Id;',
  `id_import_model` int NOT NULL DEFAULT '2' COMMENT 'select;true;true;Models; SELECT * FROM dba_imports_models;',
  `id_import_character` varchar(45) DEFAULT NULL COMMENT 'select;true;true;Codificación; SELECT * FROM dba_imports_characters;',
  `name` varchar(255) DEFAULT NULL COMMENT 'varchar;true;true;Description;',
  `file` varchar(255) DEFAULT NULL COMMENT 'file;true;true;File;;0:0:0:true',
  `ttable` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'checkbox;false;true;Truncado de tabla;',
  `field_order` int NOT NULL DEFAULT '0' COMMENT 'order;true;true;Order;',
  `date` datetime NOT NULL DEFAULT '2020-07-15 00:00:00' COMMENT 'hiddendatetime;false;true;Creation At;',
  `modified` datetime NOT NULL DEFAULT '2020-07-15 00:00:00' COMMENT 'hiddendatetime;false;true;Update At;',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'tinyint;true;false;Status;',
  PRIMARY KEY (`id_import`),
  KEY `ky_import_model` (`id_import_model`),
  KEY `index3` (`id_import_character`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3 COMMENT='true;true;false;father:;Importaciones';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dba_imports`
--

LOCK TABLES `dba_imports` WRITE;
/*!40000 ALTER TABLE `dba_imports` DISABLE KEYS */;
INSERT INTO `dba_imports` VALUES (1,1,'1','Primer importación de Observaciones','14062021_050744_10363811.csv',0,1,'2021-06-14 05:07:26','2021-06-14 05:13:21',-1),(2,2,'1','Importación de tareas','05082021_030551_12409668.csv',1,2,'2021-08-05 03:05:23','2021-08-05 03:06:39',-1),(3,3,'1','Importacion 1','19102021_131325_13511009.csv',1,3,'2021-10-19 13:12:55','2021-10-19 13:13:56',-1),(4,4,'1','Pasados por Norberto','22112021_202259_14732979.csv',0,4,'2021-10-19 13:12:55','2021-11-22 20:23:38',-1),(5,5,'1','dba_PATIENTS_EVOLUTIONS_10AL14','07022022_134750_13759622.csv',0,5,'2021-10-19 13:12:55','2022-02-07 14:43:45',0),(6,5,'1','dba_PATIENTS_EVOLUTIONS_17AL21','07022022_143612_15742144.csv',0,6,'2021-10-19 13:12:55','2022-02-07 14:43:55',0),(7,5,'1','dba_PATIENTS_EVOLUTIONS_24 AL 28','07022022_143643_19976880.csv',0,7,'2021-10-19 13:12:55','2022-02-07 14:44:03',0),(8,5,'1','dba_PATIENTS_EVOLUTIONS_31_ENERO_4_FEBRERO','07022022_143714_17102436.csv',0,8,'2021-10-19 13:12:55','2022-02-07 14:44:09',0);
/*!40000 ALTER TABLE `dba_imports` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-01 17:37:17
