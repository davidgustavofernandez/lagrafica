-- MySQL dump 10.13  Distrib 8.0.29, for Linux (x86_64)
--
-- Host: localhost    Database: developersba
-- ------------------------------------------------------
-- Server version	8.0.32-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dba_imports_models`
--

DROP TABLE IF EXISTS `dba_imports_models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dba_imports_models` (
  `id_import_model` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'hidden;true;true;Id;',
  `name` varchar(255) DEFAULT NULL COMMENT 'varchar;true;true;Table Description;',
  `table_name` varchar(255) DEFAULT NULL COMMENT 'varchar;true;true;Table Name;',
  `field_order` int NOT NULL DEFAULT '0' COMMENT 'order;true;true;Order;',
  `date` datetime NOT NULL DEFAULT '2019-04-07 00:00:00' COMMENT 'hiddendatetime;false;true;Creation At;',
  `modified` datetime NOT NULL DEFAULT '2019-04-07 00:00:00' COMMENT 'hiddendatetime;false;true;Update At;',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'tinyint;true;false;Status;',
  PRIMARY KEY (`id_import_model`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COMMENT='true;true;false;son_of:imports;Modelos;';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dba_imports_models`
--

LOCK TABLES `dba_imports_models` WRITE;
/*!40000 ALTER TABLE `dba_imports_models` DISABLE KEYS */;
INSERT INTO `dba_imports_models` VALUES (1,'Observaciones','observations',1,'2021-06-14 05:07:07','2021-06-14 05:07:07',1),(2,'Tareas','tasks',2,'2021-08-05 03:05:07','2021-08-05 03:05:07',1),(3,'Pacientes | Evoluciones | Test','patients_evolutions_test',3,'2021-10-19 13:12:33','2021-10-19 13:12:33',1),(4,'Pacientes','patients',4,'2021-10-19 13:12:33','2021-11-22 20:22:31',1),(5,'Pacientes | Evoluciones','patients_evolutions',5,'2021-10-19 13:12:33','2022-02-07 14:43:28',1);
/*!40000 ALTER TABLE `dba_imports_models` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-01 17:37:16
