-- MySQL dump 10.13  Distrib 8.0.29, for Linux (x86_64)
--
-- Host: localhost    Database: developersba
-- ------------------------------------------------------
-- Server version	8.0.32-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dba_countries_provinces`
--

DROP TABLE IF EXISTS `dba_countries_provinces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dba_countries_provinces` (
  `id_country_province` int NOT NULL AUTO_INCREMENT COMMENT 'hidden;true;true;Id;',
  `name` varchar(255) DEFAULT NULL COMMENT 'varchar;true;true;Name;',
  `field_order` int NOT NULL DEFAULT '0' COMMENT 'order;true;true;Order;',
  `date` datetime NOT NULL DEFAULT '2019-04-07 00:00:00' COMMENT 'hiddendatetime;false;true;Creation At;',
  `modified` datetime NOT NULL DEFAULT '2019-04-07 00:00:00' COMMENT 'hiddendatetime;false;true;Update At;',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'tinyint;true;false;Status;',
  PRIMARY KEY (`id_country_province`)
) ENGINE=MyISAM AUTO_INCREMENT=95 DEFAULT CHARSET=utf8mb3 COMMENT='true;true;true;son_of:countries;Provincias';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dba_countries_provinces`
--

LOCK TABLES `dba_countries_provinces` WRITE;
/*!40000 ALTER TABLE `dba_countries_provinces` DISABLE KEYS */;
INSERT INTO `dba_countries_provinces` VALUES (6,'Buenos Aires',6,'2020-07-22 02:57:57','2020-07-22 02:57:57',1),(10,'Catamarca',10,'2020-07-22 03:46:16','2020-07-22 03:46:16',1),(14,'Córdoba',14,'2020-07-22 03:46:34','2020-07-22 03:46:34',1),(18,'Corrientes',18,'2020-07-22 03:47:40','2020-07-22 03:47:40',1),(22,'Chaco',22,'2020-07-22 03:47:50','2020-07-22 03:47:50',1),(26,'Chubut',26,'2020-07-22 03:48:02','2020-07-22 03:48:02',1),(30,'Entre Ríos',30,'2020-07-22 03:48:14','2020-07-22 03:48:14',1),(34,'Formosa',34,'2020-07-22 03:48:38','2020-07-22 03:48:38',1),(38,'Jujuy',38,'2020-07-22 03:48:47','2020-07-22 03:48:47',1),(42,'La Pampa',42,'2020-07-22 03:49:07','2020-07-22 03:49:07',1),(46,'La Rioja',46,'2020-07-22 03:49:21','2020-07-22 03:49:21',1),(50,'Mendoza',50,'2020-07-22 03:49:32','2020-07-22 03:49:32',1),(54,'Misiones',54,'2020-07-22 03:49:59','2020-07-22 03:49:59',1),(58,'Neuquén',58,'2020-07-22 03:50:20','2020-07-22 03:50:20',1),(62,'Río Negro',62,'2020-07-22 03:50:30','2020-07-22 03:50:30',1),(66,'Salta',66,'2020-07-22 03:50:54','2020-07-22 03:50:54',1),(70,'San Juan',70,'2020-07-22 03:51:16','2020-07-22 03:51:16',1),(74,'San Luis',74,'2020-07-22 03:51:30','2020-07-22 03:51:30',1),(78,'Santa Cruz',78,'2020-07-22 03:51:45','2020-07-22 03:51:45',1),(82,'Santa Fe',82,'2020-07-22 03:51:50','2020-07-22 03:51:50',1),(86,'Santiago del Estero',86,'2020-07-22 03:53:02','2020-07-22 03:53:02',1),(2,'Ciudad Autónoma de Buenos Aires',2,'2020-07-22 03:53:16','2020-07-22 03:53:16',1),(90,'Tucumán',90,'2020-07-22 03:53:38','2020-07-22 03:53:38',1),(94,'Tierra del Fuego, Antártida e Islas del Atlántico Sur',94,'2020-07-22 03:54:02','2020-07-22 03:54:02',1);
/*!40000 ALTER TABLE `dba_countries_provinces` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-01 17:37:18
