-- MySQL dump 10.13  Distrib 8.0.29, for Linux (x86_64)
--
-- Host: localhost    Database: developersba
-- ------------------------------------------------------
-- Server version	8.0.32-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dba_settings`
--

DROP TABLE IF EXISTS `dba_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dba_settings` (
  `id_setting` int NOT NULL AUTO_INCREMENT COMMENT 'hidden;true;true;Id;',
  `id_country` int NOT NULL DEFAULT '2' COMMENT 'select;false;true;Country; SELECT * FROM dba_countries;',
  `id_setting_language` int NOT NULL DEFAULT '2' COMMENT 'select;false;true;Language; SELECT * FROM dba_settings_languages;',
  `name` varchar(150) DEFAULT NULL COMMENT 'varchar;true;true;Name;',
  `detail` text COMMENT 'text;false;true;Detail;',
  `keywords` varchar(150) DEFAULT NULL COMMENT 'varchar;false;true;Keywords;',
  `author` varchar(150) DEFAULT NULL COMMENT 'varchar;false;true;Author;',
  `favicon` varchar(255) DEFAULT NULL COMMENT 'file;false;true;Favicon;;0:0:0:true',
  `logo` varchar(255) DEFAULT NULL COMMENT 'file;true;true;Logo;;50:80:150:true',
  `logo_menu` varchar(255) DEFAULT NULL COMMENT 'file;false;true;Logo menu;;0:0:0:true',
  `logo_variant` varchar(255) DEFAULT NULL COMMENT 'file;false;true;Logo menu Variant;;0:0:0:true',
  `province` varchar(255) DEFAULT NULL COMMENT 'varchar;false;true;Province;',
  `address` varchar(255) DEFAULT NULL COMMENT 'varchar;false;true;Address;',
  `postal_code` varchar(255) DEFAULT NULL COMMENT 'varchar;false;true;Postal Code;',
  `phone` varchar(255) DEFAULT NULL COMMENT 'varchar;false;true;Phone;',
  `email` varchar(255) DEFAULT NULL COMMENT 'varchar;false;true;Email;',
  `no_reply_email` varchar(255) DEFAULT NULL COMMENT 'varchar;false;true;No-Reply Email;',
  `no_reply_name` varchar(255) DEFAULT NULL COMMENT 'varchar;false;true;No-Reply Name;',
  `contact_email` varchar(255) DEFAULT NULL COMMENT 'varchar;false;true;Contact Email;',
  `contact_name` varchar(255) DEFAULT NULL COMMENT 'varchar;false;true;Contact Name;',
  `url_shop` varchar(255) DEFAULT NULL COMMENT 'varcharlink;false;true;URL Shop;',
  `url_instagram` varchar(255) DEFAULT NULL COMMENT 'varcharlink;false;true;URL Instagram;',
  `url_facebook` varchar(225) DEFAULT NULL COMMENT 'varcharlink;true;true;URL Facebook;',
  `url_pinterest` varchar(225) DEFAULT NULL COMMENT 'varcharlink;false;true;URL Pinterest;',
  `google_analytics` varchar(255) DEFAULT NULL COMMENT 'varchar;false;true;Google Analytics (ID);',
  `google_ads` varchar(255) DEFAULT NULL COMMENT 'varchar;false;true;Google Ads (ID);',
  `google_maps` varchar(255) DEFAULT NULL COMMENT 'varchar;false;true;Google Maps (Key);',
  `facebook_pixel` varchar(255) DEFAULT NULL COMMENT 'varchar;false;true;Facebook Pixel (ID);',
  `activate_scripts` int DEFAULT '0' COMMENT 'checkbox;true;true;Activate Scripts;',
  `header_script` text COMMENT 'text;false;true;Header Script;',
  `middle_script` text COMMENT 'text;false;true;Middle Script;',
  `footer_script` text COMMENT 'text;false;true;Footer Script;',
  `share_email_subject` varchar(255) DEFAULT NULL COMMENT 'varchar;false;true;Share Email Subject;',
  `share_email_body` text COMMENT 'text;false;true;Share Email Body;',
  `share_hashtags` varchar(255) DEFAULT NULL COMMENT 'varchar;false;true;Share Hashtags;',
  `share_summary` text COMMENT 'text;false;true;Share Summary (Facebook);',
  `share_source` varchar(255) DEFAULT NULL COMMENT 'varchar;false;true;Share Source (Linkedin);',
  `background_img` varchar(255) DEFAULT NULL COMMENT 'file;true;true;Imagen de fondo;;50:1024:1920:true',
  `date` datetime NOT NULL DEFAULT '2019-04-07 00:00:00' COMMENT 'hiddendatetime;false;true;Creation At;',
  `modified` datetime NOT NULL DEFAULT '2019-04-07 00:00:00' COMMENT 'hiddendatetime;false;true;Update At;',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'tinyint;true;false;Status;',
  PRIMARY KEY (`id_setting`),
  KEY `ky_country` (`id_country`),
  KEY `ky_setting_language` (`id_setting_language`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COMMENT='true;true;true;father:;Configuraciones';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dba_settings`
--

LOCK TABLES `dba_settings` WRITE;
/*!40000 ALTER TABLE `dba_settings` DISABLE KEYS */;
INSERT INTO `dba_settings` VALUES (1,10,2,'A Party Book','A Party Book','A Party Book','David Gustavo Fernandez','09032023_050510_15732305.ico','09032023_075042_11135774.svg','09032023_050707_10216059.svg','09032023_075042_16450406.svg','Buenos Aires','','','','fernandezdg@gmail.com','','','fernandezdg@gmail.com','A Party Book','','https://www.instagram.com/','https://www.facebook.com/','https://ar.pinterest.com/','','','','',0,'','','','Información de interés','Para ver la nota haga clic en la siguiente URL:','','','','','2020-04-10 21:45:53','2023-03-09 07:45:37',1),(2,10,2,'SESAM','SESAM','SESAM','David Gustavo Fernandez','25022023_011729_14484380.ico','25022023_011729_15157692.png','','','Buenos Aires','','','','fernandezdg@gmail.com','','','fernandezdg@gmail.com','SESAM','','https://www.instagram.com/','https://www.facebook.com/','https://ar.pinterest.com/','','','','',0,'','','','Información de interés','Para ver la nota haga clic en la siguiente URL:','','','','16082020_174156_17706011.jpg','2020-04-10 21:45:53','2023-02-25 01:16:24',-1);
/*!40000 ALTER TABLE `dba_settings` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-01 17:37:17
