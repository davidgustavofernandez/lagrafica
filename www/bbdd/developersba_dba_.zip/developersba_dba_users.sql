-- MySQL dump 10.13  Distrib 8.0.29, for Linux (x86_64)
--
-- Host: localhost    Database: developersba
-- ------------------------------------------------------
-- Server version	8.0.32-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dba_users`
--

DROP TABLE IF EXISTS `dba_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dba_users` (
  `id_user` bigint NOT NULL AUTO_INCREMENT COMMENT 'hidden;true;true;Id;',
  `id_user_type` int NOT NULL DEFAULT '0' COMMENT 'select;true;true;Perfil; SELECT * FROM dba_users_types;',
  `first_name` varchar(255) NOT NULL COMMENT 'varchar;true;true;Nombre;',
  `last_name` varchar(255) DEFAULT NULL COMMENT 'varchar;true;true;Apellido;',
  `email` varchar(255) DEFAULT NULL COMMENT 'email;true;true;Email;',
  `password` varchar(255) DEFAULT NULL COMMENT 'password;false;true;Contraseña;',
  `cell_phone` varchar(255) DEFAULT NULL COMMENT 'varchar;false;true;Teléfono Celular;',
  `phone` varchar(255) DEFAULT NULL COMMENT 'varchar;false;true;Teléfono;',
  `birth_date` date DEFAULT '2020-04-01' COMMENT 'date;false;true;Fecha de nacimiento;',
  `dni` varchar(255) DEFAULT NULL COMMENT 'varchar;true;true;DNI;',
  `id_country` int NOT NULL DEFAULT '10' COMMENT 'select;false;true;Pais; SELECT * FROM dba_countries;',
  `id_country_province` int NOT NULL DEFAULT '1' COMMENT 'select;false;true;Provincia; SELECT * FROM dba_countries_provinces;',
  `id_country_province_locality` bigint NOT NULL DEFAULT '0' COMMENT 'select;false;true;Localidad; SELECT * FROM dba_countries_provinces_localities;',
  `city` varchar(255) DEFAULT NULL COMMENT 'varchar;false;true;Ciudad;',
  `address` varchar(255) DEFAULT NULL COMMENT 'varchar;false;true;Direccion;',
  `height` varchar(255) DEFAULT NULL COMMENT 'varchar;false;true;Altura ;',
  `floor` varchar(255) DEFAULT NULL COMMENT 'varchar;false;true;Piso;',
  `department` varchar(255) DEFAULT NULL COMMENT 'varchar;false;true;Departamento;',
  `postal_code` varchar(255) DEFAULT NULL COMMENT 'varchar;false;true;Código Postal;',
  `file` varchar(255) DEFAULT NULL COMMENT 'file;false;true;Avatar;;50:80:150:false',
  `id_user_avatar` int NOT NULL DEFAULT '0' COMMENT 'select;false;true;Avatar alernativo; SELECT * FROM dba_users_avatars;',
  `id_user_gender` int NOT NULL DEFAULT '0' COMMENT 'select;false;true;Sexo; SELECT * FROM dba_users_genders;',
  `newsletter` tinyint(1) DEFAULT '0' COMMENT 'checkbox;false;true;Newsletters;',
  `terms_and_conditions` tinyint(1) DEFAULT '0' COMMENT 'checkbox;false;true;Términos y condiciones;',
  `recover` varchar(255) DEFAULT NULL COMMENT 'hidden;false;false;Recover;',
  `activation_token` varchar(255) DEFAULT NULL COMMENT 'hidden;false;false;Token de Activación;',
  `bypass_token` varchar(255) DEFAULT NULL COMMENT 'varchar;true;true;By Pass Token;',
  `ip` varchar(255) DEFAULT NULL COMMENT 'varchar;false;false;IP;',
  `date` datetime NOT NULL DEFAULT '2020-04-01 00:00:00' COMMENT 'hiddendatetime;false;true;Creation At;',
  `modified` datetime NOT NULL DEFAULT '2020-04-01 00:00:00' COMMENT 'hiddendatetime;false;true;Update At;',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'tinyint;true;false;Status;',
  PRIMARY KEY (`id_user`),
  KEY `ky_country_province` (`id_country_province`),
  KEY `ky_country_province_locality` (`id_country_province_locality`),
  KEY `ky_user_avatar` (`id_user_avatar`),
  KEY `ky_user_gender` (`id_user_gender`),
  KEY `ky_password` (`password`),
  KEY `ky_status` (`status`),
  KEY `ky_email` (`email`),
  KEY `ky_country` (`id_country`),
  KEY `ky_user_type` (`id_user_type`),
  KEY `ky_dni` (`dni`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COMMENT='true;true;false;father:;Usuarios;';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dba_users`
--

LOCK TABLES `dba_users` WRITE;
/*!40000 ALTER TABLE `dba_users` DISABLE KEYS */;
INSERT INTO `dba_users` VALUES (1,1,'David','Fernandez','fernandezdg@gmail.com','1302011b60764557','01153340882','01153340882','1977-08-12','25975246',10,6,2070010001,'CABA','Ramon Falcon','2974','11','D','1406','09032023_055911_15640294.jpg',4,1,1,1,NULL,NULL,'',NULL,'2023-03-09 05:56:38','2023-03-11 01:28:38',1),(2,2,'Fatima','Ortellado','mikaorte2009@hotmail.com','1302011b60764557','01153340882',NULL,'2020-04-01','12333333',10,1,0,NULL,NULL,NULL,NULL,NULL,NULL,'09032023_155556_11542512.jpg',10,0,0,1,NULL,'','8qQihDkrMsMRt51u4tfknANjz','::1','2023-03-09 03:41:19','2023-03-11 07:17:52',1),(3,1,'pepe','argento','fernandezdg+pepe@gmail.com','1302011b637040','01153340882','','2020-04-01','25975246',10,0,0,'','','','','','','10032023_152749_11925235.jpg',11,0,1,1,NULL,'FC2TCKvZUw0U4lUJgzbzEOksM',NULL,'::1','2023-03-10 03:26:40','2023-03-10 03:28:56',1);
/*!40000 ALTER TABLE `dba_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-01 17:37:17
