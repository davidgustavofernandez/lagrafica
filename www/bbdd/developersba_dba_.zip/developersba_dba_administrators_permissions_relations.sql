-- MySQL dump 10.13  Distrib 8.0.29, for Linux (x86_64)
--
-- Host: localhost    Database: developersba
-- ------------------------------------------------------
-- Server version	8.0.32-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dba_administrators_permissions_relations`
--

DROP TABLE IF EXISTS `dba_administrators_permissions_relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dba_administrators_permissions_relations` (
  `id_administrator_permission_relation` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'hidden;true;true;Id;',
  `id_administrator` int DEFAULT NULL COMMENT 'select;true;true;Administrator;SELECT * FROM dba_administrators',
  `id_administrator_permission` int DEFAULT NULL COMMENT 'select;true;true;Permission;SELECT * FROM dba_administrators_permissions',
  `date` datetime NOT NULL DEFAULT '2019-04-07 00:00:00' COMMENT 'hiddendatetime;false;true;Creation At;',
  `modified` datetime NOT NULL DEFAULT '2019-04-07 00:00:00' COMMENT 'hiddendatetime;false;true;Update At;',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'tinyint;true;false;Status;',
  PRIMARY KEY (`id_administrator_permission_relation`),
  KEY `ky_administrator` (`id_administrator`),
  KEY `ky_administrator_permission` (`id_administrator_permission`)
) ENGINE=MyISAM AUTO_INCREMENT=189 DEFAULT CHARSET=utf8mb3 COMMENT='true;true;false;son_of:administrators;Relación;';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dba_administrators_permissions_relations`
--

LOCK TABLES `dba_administrators_permissions_relations` WRITE;
/*!40000 ALTER TABLE `dba_administrators_permissions_relations` DISABLE KEYS */;
INSERT INTO `dba_administrators_permissions_relations` VALUES (188,1,47,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(187,1,46,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(186,1,45,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(185,1,44,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(184,1,43,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(183,1,42,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(182,1,41,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(181,1,40,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(180,1,39,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(179,1,38,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(178,1,37,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(177,1,36,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(176,1,35,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(175,1,34,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(174,1,33,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(173,1,32,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(172,1,31,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(171,1,30,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(170,1,29,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(169,1,28,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(168,1,27,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(167,1,26,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(166,1,25,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(165,1,24,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(164,1,23,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(163,1,22,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(162,1,21,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(161,1,20,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(160,1,19,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(159,1,18,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(158,1,17,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(157,1,16,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(156,1,15,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(155,1,14,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(154,1,13,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(153,1,12,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(152,1,11,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(151,1,10,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(150,1,9,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(149,1,8,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(148,1,7,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(147,1,6,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(146,1,5,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(145,1,4,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(144,1,3,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(143,1,2,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(142,1,1,'2019-04-07 00:00:00','2019-04-07 00:00:00',1);
/*!40000 ALTER TABLE `dba_administrators_permissions_relations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-01 17:37:17
