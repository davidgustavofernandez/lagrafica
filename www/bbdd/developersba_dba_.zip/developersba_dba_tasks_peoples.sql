-- MySQL dump 10.13  Distrib 8.0.29, for Linux (x86_64)
--
-- Host: localhost    Database: developersba
-- ------------------------------------------------------
-- Server version	8.0.32-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dba_tasks_peoples`
--

DROP TABLE IF EXISTS `dba_tasks_peoples`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dba_tasks_peoples` (
  `id_task_people` int NOT NULL AUTO_INCREMENT COMMENT 'hidden;true;true;Id;',
  `name` varchar(255) DEFAULT NULL COMMENT 'varchar;true;true;Nombre;',
  `field_order` int NOT NULL DEFAULT '0' COMMENT 'order;true;true;Order;',
  `date` datetime NOT NULL DEFAULT '2019-04-07 00:00:00' COMMENT 'hiddendatetime;false;true;Creation At;',
  `modified` datetime NOT NULL DEFAULT '2019-04-07 00:00:00' COMMENT 'hiddendatetime;false;true;Update At;',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'tinyint;true;false;Status;',
  PRIMARY KEY (`id_task_people`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COMMENT='true;true;true;true;son_of:tasks;Personas';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dba_tasks_peoples`
--

LOCK TABLES `dba_tasks_peoples` WRITE;
/*!40000 ALTER TABLE `dba_tasks_peoples` DISABLE KEYS */;
INSERT INTO `dba_tasks_peoples` VALUES (1,'David Fernandez',1,'2019-07-25 12:37:29','2020-02-11 16:59:17',1),(2,'Leonardo Saroka',2,'2019-07-25 12:37:35','2020-04-03 00:59:17',1);
/*!40000 ALTER TABLE `dba_tasks_peoples` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-01 17:37:18
