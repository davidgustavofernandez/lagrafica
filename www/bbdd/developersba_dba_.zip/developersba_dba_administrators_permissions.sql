-- MySQL dump 10.13  Distrib 8.0.29, for Linux (x86_64)
--
-- Host: localhost    Database: developersba
-- ------------------------------------------------------
-- Server version	8.0.32-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dba_administrators_permissions`
--

DROP TABLE IF EXISTS `dba_administrators_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dba_administrators_permissions` (
  `id_administrator_permission` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'hidden;true;true;Id;',
  `name` varchar(255) DEFAULT NULL COMMENT 'varchar;true;true;Table Description;',
  `table_name` varchar(255) DEFAULT NULL COMMENT 'varchar;true;true;Table Name;',
  `field_order` int NOT NULL DEFAULT '0' COMMENT 'order;true;true;Order;',
  `date` datetime NOT NULL DEFAULT '2019-04-07 00:00:00' COMMENT 'hiddendatetime;false;true;Creation At;',
  `modified` datetime NOT NULL DEFAULT '2019-04-07 00:00:00' COMMENT 'hiddendatetime;false;true;Update At;',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'tinyint;true;false;Status;',
  PRIMARY KEY (`id_administrator_permission`)
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb3 COMMENT='true;true;false;son_of:administrators;Permisos';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dba_administrators_permissions`
--

LOCK TABLES `dba_administrators_permissions` WRITE;
/*!40000 ALTER TABLE `dba_administrators_permissions` DISABLE KEYS */;
INSERT INTO `dba_administrators_permissions` VALUES (1,'Inicio','start',1,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(2,'Administradores','administrators',2,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(3,'Administradores| Permisos','administrators_permissions',3,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(4,'Administradores| Permisos | Relaciones','administrators_permissions_relations',4,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(5,'Configuraciones','settings',5,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(6,'Configuraciones | Textos','settings_copys',6,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(7,'Configuraciones | Lenguajes','settings_languages',7,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(8,'Configuraciones | Monedas','settings_currencies',8,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(9,'Configuraciones | Targets','settings_targets',9,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(10,'Configuraciones | Email Template','settings_emails',10,'2019-04-07 00:00:00','2021-07-20 04:20:37',1),(11,'Paises','countries',11,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(12,'Paises | Monedas','countries_currencies',12,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(13,'Paises | Provincias','countries_provinces',13,'2020-07-22 17:35:18','2020-07-22 17:36:04',1),(14,'Paises | Provincias | Departamentos','countries_provinces_departments',14,'2020-07-22 17:35:18','2020-07-22 17:37:22',1),(15,'Paises | Provincias | Localidades','countries_provinces_localities',15,'2020-07-22 17:35:18','2020-07-22 17:37:46',1),(16,'Paises | Provincias | Municipios','countries_provinces_municipalities',16,'2020-07-22 17:35:18','2020-07-22 17:38:08',1),(17,'Paises | Provincias | Censos','countries_provinces_censuses',17,'2020-07-22 17:35:18','2020-07-25 10:08:57',1),(18,'Secciones','sections',18,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(19,'Secciones | Frecuencias','sections_frequencies',19,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(20,'Usuarios |Galerías','users_galleries',20,'2019-04-07 00:00:00','2023-03-09 06:03:24',1),(21,'Secciones | Sliders','sections_sliders',21,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(22,'Usuarios','users',22,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(23,'Usuarios | IPs','users_ips',23,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(24,'Usuarios | Seguimiento','users_trackings',24,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(25,'Usuarios | Avatar','users_avatars',25,'2020-07-27 09:51:55','2020-07-29 18:02:29',1),(26,'Usuarios | Generos','users_genders',26,'2020-07-22 18:06:43','2020-07-22 18:17:37',1),(27,'Usuarios | Tipo','users_types',27,'2020-07-27 09:51:55','2020-07-27 09:51:55',1),(28,'Usuarios | Types | Permisos','users_types_permissions',28,'2020-08-03 21:30:39','2020-08-17 02:05:54',1),(29,'Usuarios | Types | Permisos | Relaciones','users_types_permissions_relations',29,'2019-04-07 00:00:00','2020-08-17 02:06:32',1),(30,'Usuarios | Estados Civiles','users_maritalstates',30,'2020-07-22 18:06:43','2020-07-22 18:26:14',1),(31,'Usuarios | Lista de deseos','users_wishes',31,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(32,'Usuarios | Carrito','users_carts',32,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(33,'Usuarios | Estado del Carrito','users_carts_states',33,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(34,'Formularios','forms',34,'2019-04-07 00:00:00','2019-04-07 00:00:00',1),(35,'Formularios | Tipos','forms_types',35,'2019-04-07 00:00:00','2020-04-12 19:27:02',1),(36,'Importación','imports',36,'2020-06-28 05:18:39','2020-06-28 05:57:08',1),(37,'Importación | Logs','imports_logs',37,'2020-06-28 05:18:39','2020-07-15 08:47:53',1),(38,'Importación | Modelos','imports_models',38,'2020-06-28 05:18:39','2020-07-15 08:48:08',1),(39,'Importación | Modelos | Relaciones','imports_models_relations',39,'2020-06-28 05:18:39','2020-07-15 08:48:46',1),(40,'Importación | Codificación','imports_characters',40,'2020-07-22 17:35:18','2020-07-26 23:37:48',1),(41,'Tareas','tasks',41,'2020-08-03 21:49:36','2020-08-03 21:49:36',1),(42,'Tareas | Ambientes','tasks_environments',42,'2020-08-03 21:49:52','2020-08-03 21:49:52',1),(43,'Tareas | Personas','tasks_peoples',43,'2020-08-03 21:50:08','2020-08-03 21:50:08',1),(44,'Tareas | Prioridades','tasks_priorities',44,'2020-08-03 21:50:28','2020-08-03 21:50:28',1),(45,'Tareas | Recursos','tasks_resources',45,'2020-08-03 21:50:48','2020-08-03 21:50:48',1),(46,'Tareas | Sprint','tasks_sprints',46,'2020-08-03 21:51:03','2020-08-03 21:51:03',1),(47,'Tareas | Estados','tasks_states',47,'2020-08-03 21:51:16','2020-08-03 21:51:16',1);
/*!40000 ALTER TABLE `dba_administrators_permissions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-01 17:37:18
